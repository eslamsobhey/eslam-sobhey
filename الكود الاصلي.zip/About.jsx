import React from 'react';
import { motion } from 'framer-motion';
import { Mail, MessageCircle, User, Lightbulb } from 'lucide-react';
import { useData } from './DataProvider';

const About = () => {
  const { profileData } = useData();

  return (
    <section id="about" className="py-0 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-8"
        >
          <div className="flex items-center justify-center mb-4">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-800">نبذة عني</h2>
            <User className="text-teal-600 mr-2" size={32} />
          </div>

        </motion.div>

        <div className="flex flex-col items-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="mb-8"
          >
            <img 
              src="/profile.jpg" 
              alt="صورة شخصية"
              className="w-48 h-48 rounded-full object-cover"
            />
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            viewport={{ once: true }}
            className="max-w-4xl text-center space-y-6"
          >
            <p className="text-lg text-gray-600 leading-relaxed whitespace-pre-line">
              {profileData.description}
            </p>

            <div className="flex items-center justify-center space-x-4 rtl:space-x-reverse pt-6">
              <Lightbulb className="text-teal-600" size={24} />
              <span className="text-lg font-medium text-gray-800">
                "البيزنس الناجح بيني محتوي ناجح" 👌
              </span>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default About;


