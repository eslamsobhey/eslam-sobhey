import React, { useState } from 'react';

const Courses = () => {
  const [showFullText, setShowFullText] = useState({});

  const courses = [
    {
      id: 'learning_skills',
      title: 'Certificate of Achievement',
      shortDescription: 'Has successfully passed',
      fullDescription: `إتعلمت في الدورة كيفية تطوير مهارات التعلم ،كيفية التعلم بفاعلية أكبر. إتعلمت فيها استراتيجيات التعلم السريع، وكيفية تنظيم المعلومات وتذكرها، وطرق تحسين التركيز والإنتاجية، وكيفية تطبيق ما تتعلمه في الحياة العملية.`,
      certificateImage: '/certificates/black_certificate.png',
    },
    {
      id: 'new_certificate',
      title: 'Certificate of Achievement',
      shortDescription: 'Has completed Content 101 Program For 13 hours',
      fullDescription: `13 ساعه تعلمت فيها كيفية العمل بمنهجية واضحة بدل العشوائية ، إمتى أستخدم كل نوع من أنواع الكتابة،كيفية بناء محتوى يخدم أهداف العلامة التجارية،الدمج بين علم التسويق والكتابة، كيفية إستخدام ChatGPT بشكل يخدمني ويطوّر شغلي، الكورس عبارة عن منهجية متكاملة ساعدتني أتعلم كتابة المحتوى التسويقي.`,
      certificateImage: '/certificates/new_certificate.png',
    },
  ];

  return (
    <section id="courses" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 className="text-4xl md:text-5xl font-bold text-gray-800 mb-8">دوراتي</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 justify-items-center max-w-4xl mx-auto">
          {courses.map((course) => (
            <div key={course.id} className="flex flex-col items-center bg-white p-8 rounded-lg shadow-md">
              <img 
                src={course.certificateImage} 
                alt={course.title} 
                className="w-full h-auto rounded-lg mb-6"
              />
              <h3 className="text-2xl font-bold text-gray-800 mb-4">{course.title}</h3>
              <p className="text-lg text-gray-600 leading-relaxed mb-4">
                {showFullText[course.id] ? course.fullDescription : course.shortDescription}
              </p>
              {!showFullText[course.id] && (
                <button 
                  onClick={() => setShowFullText({ ...showFullText, [course.id]: true })}
                  className="text-teal-600 hover:text-teal-800 font-medium"
                >
                  عرض المزيد
                </button>
              )}
              {showFullText[course.id] && (
                <button 
                  onClick={() => setShowFullText({ ...showFullText, [course.id]: false })}
                  className="text-teal-600 hover:text-teal-800 font-medium"
                >
                  عرض أقل
                </button>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Courses;


