import React from 'react';
import { motion } from 'framer-motion';
import { useData } from './DataProvider';

const Hero = () => {
  const { profileData } = useData();

  return (
    <section id="home" className="min-h-screen bg-white flex items-center justify-center relative py-0">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="space-y-6"
        >
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-5xl md:text-7xl font-bold text-gray-800 mb-4"
          >
            مرحباً أنا
          </motion.h1>
          
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="text-7xl md:text-9xl font-bold text-teal-600 mb-6"
          >
            {profileData.name}
          </motion.h2>
          
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="text-xl md:text-2xl text-gray-600 max-w-3xl mx-auto mb-0"
          >
            {profileData.title}
          </motion.p>
          
          
        </motion.div>
      </div>
    </section>
  );
};

export default Hero;


