import React from 'react';
import DataProvider from './components/DataProvider';
import Header from './components/Header';
import Hero from './components/Hero';
import About from './components/About';
import Courses from './components/Courses';
import Services from './components/Services';
import Portfolio from './components/Portfolio';
import Contact from './components/Contact';
import Footer from './components/Footer';
import './App.css';

function App() {
  return (
    <DataProvider>
      <div className="App rtl">
        <Header />
        <Hero />
        <About />
        <Courses />
        <Services />
        <Portfolio />
        <Contact />
        <Footer />
      </div>
    </DataProvider>
  );
}

export default App;


