import React from 'react';

const Services = () => {
  const servicesList = [
    {
      title: 'كتابة المحتوى التسويقي',
      description: 'أقوم بكتابة محتوى تسويقي جذاب ومقنع يساعد العلامات التجارية والشركات علي  على تحقيق نتائج ملموسة من خلال محتوى مكتوب بإستراتيجية واضحة يخلق تواصل فعّال مع الجمهور، يحافظ على العملاء'
    },
    {
      title: 'كتابة النصوص الإعلانية',
      description: 'أكتب نصوص إعلانية فعالة تركز علي نقاط الألم والإحتياج وتحفز الجمهور على اتخاذ الإجراء المطلوب.'
    }
  ];

  return (
    <section id="services" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 className="text-4xl md:text-5xl font-bold text-gray-800 mb-8">خدماتي</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {servicesList.map((service, index) => (
            <div key={index} className="bg-gray-50 p-8 rounded-lg shadow-md">
              <h3 className="text-2xl font-bold text-gray-800 mb-4">{service.title}</h3>
              <p className="text-lg text-gray-600 leading-relaxed">{service.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;


