import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useData } from './DataProvider';
import { Eye } from 'lucide-react';

const Portfolio = () => {
  const { projects } = useData();
  const [activeCategory, setActiveCategory] = useState('الكل');
  const [selectedProject, setSelectedProject] = useState(null);

  const categories = ['الكل', ...new Set(projects.map(project => project.category))];

  const filteredProjects = activeCategory === 'الكل'
    ? projects
    : projects.filter(project => project.category === activeCategory);

  const handleViewDetails = (project) => {
    setSelectedProject(project);
  };

  const handleCloseDetails = () => {
    setSelectedProject(null);
  };

  return (
    <section id="portfolio" className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-4xl font-extrabold text-center text-gray-900 mb-12">
          أعمالي
        </h2>
        <div className="flex justify-center mb-8 space-x-6 rtl:space-x-reverse">
          {categories.map((category, index) => (
            <button
              key={category}
              onClick={() => setActiveCategory(category)}
              className={`px-4 py-2 rounded-full text-sm font-medium ${activeCategory === category ? 'bg-teal-600 text-white' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'}`}
            >
              {category}
            </button>
          ))}
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProjects.map((project, index) => (
            <motion.div
              key={project.id}
              className="bg-white rounded-lg shadow-lg overflow-hidden"
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <div className="p-6">
                <h3 className="text-xl font-semibold text-gray-800 mb-2">{project.title}</h3>
                <p className="text-gray-600 text-sm mb-4">{project.description}</p>
                <div className="flex justify-between items-center mt-2">
                  <span className="inline-block bg-teal-100 text-teal-800 text-xs px-3 py-1 rounded-full font-semibold">{project.category}</span>
                  <button
                    onClick={() => handleViewDetails(project)}
                    className="bg-teal-600 text-white py-1 px-3 rounded-md hover:bg-teal-700 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:ring-offset-2 text-sm"
                  >
                    عرض <Eye className="inline-block w-4 h-4 ml-1" />
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {selectedProject && (
          <div className="fixed inset-0 bg-gray-800 bg-opacity-75 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full p-6 relative">
              <button
                onClick={handleCloseDetails}
                className="absolute top-3 right-3 text-gray-500 hover:text-gray-700 text-2xl"
              >
                &times;
              </button>
              <h3 className="text-2xl font-bold text-gray-800 mb-4">{selectedProject.title}</h3>
              <p className="text-gray-700 whitespace-pre-line mb-4">{selectedProject.content}</p>
              <span className="inline-block bg-teal-100 text-teal-800 text-xs px-3 py-1 rounded-full font-semibold">{selectedProject.category}</span>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};

export default Portfolio;


