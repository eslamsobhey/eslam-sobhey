import React from 'react';
import { useData } from './DataProvider';
import { MessageCircle, Mail } from 'lucide-react';

const Contact = () => {
  const { profileData } = useData();

  return (
    <section id="contact" className="py-20 bg-gradient-to-br from-teal-50 to-blue-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-800 mb-4">تواصل معي</h2>
        </div>

        <div className="max-w-4xl mx-auto">
          <div className="grid md:grid-cols-1 gap-12">
            {/* Contact Info */}
            <div className="space-y-8 text-center">
              <p className="text-gray-600 mb-8 leading-relaxed">
                إن كان لديك أي استفسار،أو تريد التعاون معي في مشروع جديد، تواصل معي🤝
              </p>

              <a 
                href="https://wa.me/201040286108"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center w-full bg-green-500 text-white rounded-full py-4 px-6 shadow-lg hover:bg-green-600 transition-colors space-x-2 rtl:space-x-reverse mb-4"
              >
                <MessageCircle className="w-8 h-8" />
                <span className="text-2xl font-bold">التواصل عبر الواتساب</span>
              </a>
              <a 
                href="mailto:eslamsobhe7gmal@gmail.com"
                className="inline-flex items-center justify-center w-full bg-blue-500 text-white rounded-full py-4 px-6 shadow-lg hover:bg-blue-600 transition-colors space-x-2 rtl:space-x-reverse"
              >
                <Mail className="w-8 h-8" />
                <span className="text-2xl font-bold">تواصل معي عبر البريد</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;


